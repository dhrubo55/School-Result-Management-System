package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.util.Scanner;

public class Main extends Application {

    Stage window;
    private Button schoolResultAutomation;

    public static void main(String[] args) throws Exception
    {

        //Database Integration
//        Scanner k = new Scanner(System.in);
//        System.out.println("Please enter the local host url with complete path info");
//        String url =  k.nextLine();
//        System.out.println("Please enter the user name");
//        String user = k.nextLine();
//        System.out.println("Please enter the password");
//        String pass = k.nextLine();
//
//        System.out.println("Enter Database Name");
//        String db_name = k.nextLine();
//        System.out.println("Enter student table name");
//        String table_name = k.nextLine();
        bluePrint d = new bluePrint("jdbc:mysql://localhost:3311/","root","root");
        d.createDB("result_processing_db");
        //d.createUserTable();
        //d.createStudentTable("std_info");
        System.out.println("test");
// for testing purpose comment this section.


        System.out.println(args);
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception{

        schoolResultAutomation= new Button("School Result Automation");
        schoolResultAutomation.setOnAction( event -> {logIn.logInPage();
            primaryStage.close();
        });


        StackPane root=new StackPane();
        root.getChildren().add(schoolResultAutomation);


     //   Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        primaryStage.setTitle("School Result Automation");
        primaryStage.setScene(new Scene(root, 1300, 700));
        primaryStage.show();
    }



}
