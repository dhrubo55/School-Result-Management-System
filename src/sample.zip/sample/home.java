package sample;

import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * Created by Murshid on 7/9/2017.
 */
public class home {

    private static String[] [] nameAndPass;
    private static boolean [][] access;
    //private static Scene window;


    public static void homePage(String name)
    {
        Stage window=new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("HOME");

        HBox top=new HBox();
        Button HHome=new Button("Home");
        Region reg=new Region();
        Button HLogOut=new Button("Log Out");
        //Button HAccount=new Button("Account");
        top.getChildren().addAll(HHome, reg, HLogOut);

        HHome.setMinSize(100,25);
        reg.setPrefSize(680,25);
        HLogOut.setMinSize(100,25);
        //HAccount.setMinSize(100,25);

        //Set color for Log out Button
        HLogOut.setBackground(new Background(new BackgroundFill(
                Color.AQUA, CornerRadii.EMPTY, Insets.EMPTY)));
        //Set on Action
        String[] args={"[Ljava.lang.String;@76fb509a"};
        HLogOut.setOnAction((ActionEvent e) ->{
            logIn.logInPage();
         //   Main.main(args);
            window.close();
        });

        VBox left=new VBox();
        left.setPadding(new Insets(10,10,10,0));
        Button LProfile=new Button("Profile");
        //Button LBio=new Button("Bio");
        Button LClass=new Button("Class Teacher");
        Button LSubjectTeacher=new Button("Subject Teacher");
        Button LRoutine=new Button("Class Routine");
        left.getChildren().addAll(LProfile,LClass, LSubjectTeacher, LRoutine);

        LProfile.setMaxSize(120,20);
        //LBio.setMaxSize(120,20);
        LClass.setMaxSize(120,20);
        LSubjectTeacher.setMaxSize(120,20);
        LRoutine.setMaxSize(120,20);






        HBox bot=new HBox();
        Label label=new Label("@ADON,RION,MOHIBUL&EMRUL for cse310");
        bot.getChildren().addAll(label);

        BorderPane bp=new BorderPane();
        bp.setTop(top);
        bp.setLeft(left);
        //bp.setCenter(center);
        bp.setBottom(bot);

        Scene sce=new Scene(bp, 1000,700);
        window.setScene(sce);
        window.show();


    }

    private static void setAccessControl(String name)
    {
        String [][] nameAndPass= logIn.getNameAndPass();
        access=new boolean[10][2];
        access[0][0]=true; access[0][1]=true;
        access[1][0]=true; access[1][1]=true;
        access[2][0]=true; access[2][1]=true;
        access[3][0]=true; access[3][1]=true;
        access[4][0]=true; access[4][1]=true;
        access[5][0]=false; access[5][1]=true;
    }




}
