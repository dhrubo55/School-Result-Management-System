package sample;
import java.sql.*;
//import java.util.Scanner;

public class bluePrint {

    public Connection conn = null;

    public bluePrint(String address, String user, String password) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            //String url = "jdbc:mysql://localhost:3311/Crawler";
            String url = address;
            conn = DriverManager.getConnection(url,user,password);
            System.out.println("conn built");
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void createDB(String dbName) throws Exception {
        //boolean flag = false;
        String sql0;
        Statement stmt;
        ResultSet resultSet = conn.getMetaData().getCatalogs();
        String databaseName = "";
        //iterate each catalog in the ResultSet
        while (resultSet.next()) {
            // Get the database name, which is at position 1
            databaseName = resultSet.getString(1);
        }


        if (databaseName.equals("result_processing_db")) {

            try
            {
                stmt = conn.createStatement();
                sql0 = "use " + databaseName;
                stmt.executeUpdate(sql0);
            }
            catch (Exception e)
            {

            }

        } else {
            Statement stmt1;
            Statement stmt2;
            Statement stmt3;
            String sql;
            String sql1;
            String sql2;
            String sql3;

            // boolean flag = false;
            try {
                stmt1 = conn.createStatement();
                stmt2 = conn.createStatement();
                sql = "create database " + dbName;
                stmt1.executeUpdate(sql);
                sql1 = "use " + dbName;
                stmt1.executeUpdate(sql1);

                sql2 = "create table user"+
                        "(id integer not null, "+
                        " user_name varchar(50), "+
                        " pass varchar(50), "+
                        " primary key ( id ))";

                stmt2.executeUpdate(sql2);

                stmt3 = conn.createStatement();
                sql3 = "create table " +"std_info"+
                        "(id integer not null, " +
                        " first_name varchar(50), " +
                        " last_name  varchar(50), " +
                        " age   integer, " +
                        "roll integer, "+
                        " primary key ( id ))";

                stmt3.executeUpdate(sql3);
            } finally {

            }

        }
        resultSet.close();
    }

//    public void createStudentTable(String std_tableName) throws Exception
//    {
//        System.out.println("Creating student table");
//        Statement stmt;
//        String sql;
//        try
//        {
//
//        }
//        finally
//        {
//        }
//
//    }

//    public void createUserTable() throws Exception
//    {
//        System.out.println("Creating user table");
//        Statement stmt;
//        String sql;
//
//
//        boolean tExists = false;
////        ResultSet rs = conn.getMetaData().getTables(null, null, "user", null);
////        try {
////            while (rs.next()) {
////                String tName = rs.getString("TABLE_NAME");
////                if (tName != null && tName.equals("user")) {
////                    tExists = true;
////                    break;
////                }
////            }
////        }
////        catch (Exception e){
////
////        }
//
//
//        DatabaseMetaData md = conn.getMetaData();
//        ResultSet rs = md.getTables(null, null, "%", null);
//        while(rs.next())
//        {
//            String tName = rs.getString(3);
//                if (tName != null && tName.equals("user")) {
//                    tExists = true;
//                    break;
//                }
//        }
//
//        if (tExists)
//        {
//
//        }
//        else
//        {
//            try
//            {
//                stmt = conn.createStatement();
//
//            }
//            finally
//            {
//            }
//        }
//    }
//
//
//






// public ResultSet runSql(String sql) throws SQLException {
//  Statement sta = conn.createStatement();
//  return sta.executeQuery(sql);
// }
//
// public boolean runSql2(String sql) throws SQLException {
//  Statement sta = conn.createStatement();
//  return sta.execute(sql);
// }
//
// @Override
// protected void finalize() throws Throwable {
//  if (conn != null || !conn.isClosed()) {
//   conn.close();
//  }
// }
}